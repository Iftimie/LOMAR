import numpy as np
import functions

#creating the set of macs
file = open("LOMAR2.log","r")
setMACS = set()
for line in file:
    linedata = line.split(",")
    for x in range(2,len(linedata)):
        rssi = linedata[x].split(" ")[0]
        mac = linedata[x].split(" ")[1].replace("\n","")
        # some mac strings had at the end \n resulting in duplicates like 'E8:94:F6:67:A5:EB' and 'E8:94:F6:67:A5:EB\n'
        setMACS.add(mac)
file.close()

listaMACS = list(setMACS)
listaMACS.sort()
#saving the distinct MACs
# print (len(listaMACS))
# file = open("distinctMACs.txt","w")
# for mac in listaMACS:
#     file.write(mac+"\n")
# file.close()

#creating the training data
inputSize = len(listaMACS)
minStrength = 0
Y = []
X = []
file = open("LOMAR2.log","r")
for line in file:
    linedata = line.split(",")
    Y.append([float(linedata[0]),float(linedata[1])]) #x and y coordinates
    featureVector = np.full((1, inputSize), minStrength)
    for x in range(2, len(linedata)):
        rssi = linedata[x].split(" ")[0]
        mac = linedata[x].split(" ")[1].replace("\n", "")
        index = listaMACS.index(mac)
        featureVector[0, index] = float(rssi)
    X.append(np.squeeze(np.asarray(featureVector)))

X = np.array(X)
Y = np.array(Y)
np.save("X.npy",X)
np.save("Y.npy",Y)

file = open("LOMAR_DATASET.log","w")
for i in range(0,len(Y)):
    file.write(str(Y[i,0])+","+str(Y[i,1]))
    for j in range(0, X.shape[1]):
        file.write(","+str(X[i,j]))
    file.write("\n")
file.close()


functions.plotSet(Y)